import { 
  users, type User, type InsertUser,
  messages, type Message, type InsertMessage
} from "@shared/schema";
import { db } from "./db";
import { eq, ne, and, or, desc, asc } from "drizzle-orm";

// Define interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByContact(contact: string): Promise<User | undefined>;
  createUser(user: Omit<InsertUser, "confirmPassword">): Promise<User>;
  updateUser(id: number, userData: Partial<Omit<User, "id">>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  
  // Message operations
  createMessage(message: InsertMessage): Promise<Message>;
  getMessages(userId: number): Promise<Message[]>;
  getConversation(user1Id: number, user2Id: number): Promise<Message[]>;
  markAsRead(messageId: number): Promise<boolean>;
  
  // Search operations
  searchUsers(criteria: Partial<Omit<User, "id" | "password" | "createdAt">>): Promise<User[]>;
  findMatches(userId: number): Promise<User[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private messages: Map<number, Message>;
  private userIdCounter: number;
  private messageIdCounter: number;

  constructor() {
    this.users = new Map();
    this.messages = new Map();
    this.userIdCounter = 1;
    this.messageIdCounter = 1;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByContact(contact: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.contact === contact
    );
  }

  async createUser(userData: Omit<InsertUser, "confirmPassword">): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...userData, id, createdAt: new Date().toISOString() };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<Omit<User, "id">>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }

  // Message operations
  async createMessage(messageData: InsertMessage): Promise<Message> {
    const id = this.messageIdCounter++;
    const message: Message = { 
      ...messageData, 
      id, 
      read: false, 
      createdAt: new Date().toISOString() 
    };
    this.messages.set(id, message);
    return message;
  }

  async getMessages(userId: number): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(
      (message) => message.senderId === userId || message.receiverId === userId
    ).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getConversation(user1Id: number, user2Id: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(
        (message) => 
          (message.senderId === user1Id && message.receiverId === user2Id) || 
          (message.senderId === user2Id && message.receiverId === user1Id)
      )
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }

  async markAsRead(messageId: number): Promise<boolean> {
    const message = this.messages.get(messageId);
    if (!message) return false;
    
    message.read = true;
    this.messages.set(messageId, message);
    return true;
  }

  // Search operations
  async searchUsers(criteria: Partial<Omit<User, "id" | "password" | "createdAt">>): Promise<User[]> {
    return Array.from(this.users.values()).filter(user => {
      for (const [key, value] of Object.entries(criteria)) {
        if (value && user[key as keyof typeof user] !== value) {
          return false;
        }
      }
      return true;
    });
  }

  async findMatches(userId: number): Promise<User[]> {
    const user = this.users.get(userId);
    if (!user) return [];

    return Array.from(this.users.values()).filter(otherUser => {
      // Don't include the user itself
      if (otherUser.id === userId) return false;
      
      // Match when current user's desired location matches other user's current location
      // AND other user's desired location matches current user's current location
      return (
        otherUser.currentProvince === user.desiredProvince &&
        (user.desiredDistrict === "" || otherUser.currentDistrict === user.desiredDistrict) &&
        otherUser.desiredProvince === user.currentProvince &&
        (otherUser.desiredDistrict === "" || otherUser.desiredDistrict === user.currentDistrict) &&
        otherUser.sector === user.sector &&
        otherUser.salaryLevel === user.salaryLevel
      );
    });
  }
}

import { DatabaseStorage } from "./storage-db";
export const storage = new DatabaseStorage();
