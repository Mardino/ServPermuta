import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  loginSchema, 
  insertUserSchema, 
  insertMessageSchema,
  forgotPasswordSchema
} from "@shared/schema";
import { sendPasswordResetCode, sendMatchNotification, sendMessageNotification } from "./whatsapp";
import * as crypto from "crypto";
import session from "express-session";
import MemoryStore from "memorystore";

declare module "express-session" {
  interface SessionData {
    userId: number;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Session configuration
  const MemoryStoreSession = MemoryStore(session);
  app.use(
    session({
      cookie: { maxAge: 86400000, secure: false },
      store: new MemoryStoreSession({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
      resave: false,
      saveUninitialized: false,
      secret: process.env.SESSION_SECRET || "permuta-ja-secret",
    })
  );

  // Authentication middleware
  const requireAuth = (req: Request, res: Response, next: Function) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  // User routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validationResult = insertUserSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: validationResult.error.errors 
        });
      }

      const { confirmPassword, ...userData } = validationResult.data;
      
      // Check if user already exists
      const existingUser = await storage.getUserByContact(userData.contact);
      if (existingUser) {
        return res.status(409).json({ message: "User with this contact already exists" });
      }

      // Hash password
      const hashedPassword = hashPassword(userData.password);
      
      // Create user
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword
      });

      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      // Set session
      req.session.userId = user.id;
      
      return res.status(201).json(userWithoutPassword);
    } catch (error) {
      console.error("Registration error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const validationResult = loginSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: validationResult.error.errors 
        });
      }

      const { contact, password } = validationResult.data;
      
      // Get user
      const user = await storage.getUserByContact(contact);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Verify password
      if (!verifyPassword(password, user.password)) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Set session
      req.session.userId = user.id;
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;
      
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(err => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.clearCookie("connect.sid");
      return res.status(200).json({ message: "Logged out successfully" });
    });
  });

  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const validationResult = forgotPasswordSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: validationResult.error.errors 
        });
      }

      const { contact } = validationResult.data;
      
      // Check if user exists
      const user = await storage.getUserByContact(contact);
      if (!user) {
        // For security reasons, don't reveal if the user exists
        return res.status(200).json({ message: "If your account exists, a reset code will be sent to your WhatsApp number" });
      }

      // Generate a random 6-digit code
      const resetCode = Math.floor(100000 + Math.random() * 900000).toString();
      
      // Store the reset code and expiration (in a real app, this would be in a database)
      // Here we'll use a simple in-memory map for demo purposes
      const resetCodes = new Map();
      resetCodes.set(contact, {
        code: resetCode,
        expires: new Date(Date.now() + 15 * 60 * 1000), // 15 minutes
      });
      
      // Send the reset code via WhatsApp
      await sendPasswordResetCode(contact, resetCode);
      
      return res.status(200).json({ message: "If your account exists, a reset code will be sent to your WhatsApp number" });
    } catch (error) {
      console.error("Forgot password error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Rota para alterar senha
  app.put("/api/auth/change-password", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const { currentPassword, newPassword } = req.body;
      
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: "Current password and new password are required" });
      }
      
      // Obter usuário
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Verificar senha atual
      if (!verifyPassword(currentPassword, user.password)) {
        return res.status(401).json({ message: "Current password is incorrect" });
      }
      
      // Validar nova senha
      if (newPassword.length < 8 || !/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/.test(newPassword)) {
        return res.status(400).json({ 
          message: "Password must be at least 8 characters with at least one letter and one number" 
        });
      }
      
      // Atualizar senha
      const hashedPassword = hashPassword(newPassword);
      await storage.updateUser(userId, { password: hashedPassword });
      
      return res.status(200).json({ message: "Password updated successfully" });
    } catch (error) {
      console.error("Change password error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.get("/api/auth/me", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error("Get user error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Rota para excluir conta
  app.delete("/api/users/account", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      
      // Excluir usuário
      const success = await storage.deleteUser(userId);
      
      if (!success) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Destruir sessão
      req.session.destroy(err => {
        if (err) {
          return res.status(500).json({ message: "Failed to logout after account deletion" });
        }
        
        res.clearCookie("connect.sid");
        return res.status(200).json({ message: "Account deleted successfully" });
      });
    } catch (error) {
      console.error("Delete account error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // User profile routes
  app.put("/api/users/profile", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const updatedUser = await storage.updateUser(userId, req.body);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "Failed to update user" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = updatedUser;
      
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error("Update user error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Message routes
  app.post("/api/messages", requireAuth, async (req, res) => {
    try {
      const validationResult = insertMessageSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: validationResult.error.errors 
        });
      }

      const senderId = req.session.userId!;
      const { receiverId, content } = validationResult.data;
      
      // Get sender information for notification
      const sender = await storage.getUser(senderId);
      if (!sender) {
        return res.status(404).json({ message: "Sender not found" });
      }
      
      // Get receiver information for notification
      const receiver = await storage.getUser(receiverId);
      if (!receiver) {
        return res.status(404).json({ message: "Receiver not found" });
      }
      
      // Create message
      const message = await storage.createMessage({
        senderId,
        receiverId,
        content
      });
      
      // Send WhatsApp notification to receiver
      await sendMessageNotification(
        receiver.contact, 
        `${sender.name} ${sender.surname}`
      );
      
      return res.status(201).json(message);
    } catch (error) {
      console.error("Create message error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/messages", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const messages = await storage.getMessages(userId);
      
      return res.status(200).json(messages);
    } catch (error) {
      console.error("Get messages error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/messages/:userId", requireAuth, async (req, res) => {
    try {
      const currentUserId = req.session.userId!;
      const otherUserId = parseInt(req.params.userId);
      
      if (isNaN(otherUserId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const conversation = await storage.getConversation(currentUserId, otherUserId);
      
      return res.status(200).json(conversation);
    } catch (error) {
      console.error("Get conversation error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put("/api/messages/:messageId/read", requireAuth, async (req, res) => {
    try {
      const messageId = parseInt(req.params.messageId);
      
      if (isNaN(messageId)) {
        return res.status(400).json({ message: "Invalid message ID" });
      }
      
      const success = await storage.markAsRead(messageId);
      
      if (!success) {
        return res.status(404).json({ message: "Message not found" });
      }
      
      return res.status(200).json({ message: "Message marked as read" });
    } catch (error) {
      console.error("Mark message as read error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Search and match routes
  app.get("/api/search", requireAuth, async (req, res) => {
    try {
      const searchCriteria: Record<string, any> = {};
      
      // Extract search parameters
      if (req.query.sector) searchCriteria.sector = req.query.sector;
      if (req.query.salaryLevel) searchCriteria.salaryLevel = parseInt(req.query.salaryLevel as string);
      if (req.query.currentProvince) searchCriteria.currentProvince = req.query.currentProvince;
      if (req.query.currentDistrict) searchCriteria.currentDistrict = req.query.currentDistrict;
      if (req.query.desiredProvince) searchCriteria.desiredProvince = req.query.desiredProvince;
      if (req.query.desiredDistrict) searchCriteria.desiredDistrict = req.query.desiredDistrict;
      
      const users = await storage.searchUsers(searchCriteria);
      
      // Remove passwords from response
      const usersWithoutPasswords = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      return res.status(200).json(usersWithoutPasswords);
    } catch (error) {
      console.error("Search error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/matches", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const matches = await storage.findMatches(userId);
      
      // Remove passwords from response
      const matchesWithoutPasswords = matches.map(match => {
        const { password, ...matchWithoutPassword } = match;
        return matchWithoutPassword;
      });
      
      return res.status(200).json(matchesWithoutPasswords);
    } catch (error) {
      console.error("Get matches error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper functions
function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
}

function verifyPassword(password: string, storedPassword: string): boolean {
  const [salt, hash] = storedPassword.split(':');
  const computedHash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return hash === computedHash;
}
