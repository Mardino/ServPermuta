import { 
  users, type User, type InsertUser,
  messages, type Message, type InsertMessage
} from "@shared/schema";
import { db } from "./db";
import { eq, ne, and, or, desc, asc } from "drizzle-orm";
import { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByContact(contact: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.contact, contact));
    return user || undefined;
  }

  async createUser(userData: Omit<InsertUser, "confirmPassword">): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...userData,
        createdAt: new Date().toISOString()
      })
      .returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<Omit<User, "id">>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser || undefined;
  }

  async deleteUser(id: number): Promise<boolean> {
    await db
      .delete(users)
      .where(eq(users.id, id));
    // Na drizzle-orm, não há retorno de count.
    // Vamos verificar se o usuário ainda existe para determinar sucesso
    const user = await this.getUser(id);
    return user === undefined;
  }

  async createMessage(messageData: InsertMessage): Promise<Message> {
    const [message] = await db
      .insert(messages)
      .values({
        ...messageData,
        read: false,
        createdAt: new Date().toISOString()
      })
      .returning();
    return message;
  }

  async getMessages(userId: number): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(
        or(
          eq(messages.senderId, userId),
          eq(messages.receiverId, userId)
        )
      )
      .orderBy(desc(messages.createdAt));
  }

  async getConversation(user1Id: number, user2Id: number): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(
        or(
          and(
            eq(messages.senderId, user1Id),
            eq(messages.receiverId, user2Id)
          ),
          and(
            eq(messages.senderId, user2Id),
            eq(messages.receiverId, user1Id)
          )
        )
      )
      .orderBy(asc(messages.createdAt));
  }

  async markAsRead(messageId: number): Promise<boolean> {
    const [updatedMessage] = await db
      .update(messages)
      .set({ read: true })
      .where(eq(messages.id, messageId))
      .returning();
    return updatedMessage !== undefined;
  }

  async searchUsers(criteria: Partial<Omit<User, "id" | "password" | "createdAt">>): Promise<User[]> {
    let query = db.select().from(users);
    
    for (const [key, value] of Object.entries(criteria)) {
      if (key !== 'password' && key !== 'id' && key !== 'createdAt' && value) {
        // @ts-ignore - Este é um caso em que sabemos que a propriedade existe
        query = query.where(eq(users[key], value));
      }
    }
    
    return await query;
  }

  async findMatches(userId: number): Promise<User[]> {
    const user = await this.getUser(userId);
    if (!user) return [];

    return await db
      .select()
      .from(users)
      .where(
        and(
          ne(users.id, userId),
          eq(users.currentProvince, user.desiredProvince),
          eq(users.sector, user.sector),
          eq(users.salaryLevel, user.salaryLevel),
          eq(users.desiredProvince, user.currentProvince)
        )
      );
  }
}