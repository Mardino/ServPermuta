import { Route, Switch } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Welcome from "@/pages/welcome";
import Login from "@/pages/login";
import Register from "@/pages/register";
import ForgotPassword from "@/pages/forgot-password";
import Home from "@/pages/home";
import Search from "@/pages/search";
import Messages from "@/pages/messages";
import Chat from "@/pages/messages/chat";
import Profile from "@/pages/profile";
import ProfileEdit from "@/pages/profile-edit";
import ChangePassword from "@/pages/change-password";
import DeleteAccount from "@/pages/delete-account";
import About from "@/pages/about";
import Terms from "@/pages/terms";
import Privacy from "@/pages/privacy";
import { AuthProvider } from "@/hooks/use-auth";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Welcome} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/forgot-password" component={ForgotPassword} />
      <Route path="/home" component={Home} />
      <Route path="/search" component={Search} />
      <Route path="/messages" component={Messages} />
      <Route path="/messages/:id" component={Chat} />
      <Route path="/profile" component={Profile} />
      <Route path="/profile/edit" component={ProfileEdit} />
      <Route path="/profile/change-password" component={ChangePassword} />
      <Route path="/profile/delete-account" component={DeleteAccount} />
      <Route path="/about" component={About} />
      <Route path="/terms" component={Terms} />
      <Route path="/privacy" component={Privacy} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </AuthProvider>
  );
}

export default App;
