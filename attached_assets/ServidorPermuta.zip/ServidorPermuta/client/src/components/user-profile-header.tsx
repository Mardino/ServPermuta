import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Edit } from "lucide-react";

interface UserProfileHeaderProps {
  user: any; // Type should be User from schema, but without password
}

export function UserProfileHeader({ user }: UserProfileHeaderProps) {
  const [_, navigate] = useLocation();
  
  return (
    <Card className="rounded-lg shadow-sm p-6 mb-6 text-center">
      <div className="w-24 h-24 rounded-full bg-primary/20 text-primary flex items-center justify-center mx-auto mb-4 text-4xl font-light">
        {user.name ? user.name.charAt(0).toUpperCase() : "U"}
      </div>
      <h2 className="text-xl font-medium mb-1">{user.name} {user.surname}</h2>
      <p className="text-neutral-500 mb-3">
        {user.sector} • Nível {user.salaryLevel}, Escalão {user.grade}
      </p>
      <Button 
        variant="outline" 
        className="w-full py-2 text-secondary border border-secondary rounded-lg font-medium flex justify-center items-center"
        onClick={() => navigate("/profile/edit")}
      >
        <Edit className="h-4 w-4 mr-1" />
        Editar Perfil
      </Button>
    </Card>
  );
}
