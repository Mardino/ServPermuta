import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";

export function SupportFooter() {
  const [_, navigate] = useLocation();
  
  return (
    <div className="w-full text-center py-6 text-xs text-neutral-500">
      <div className="flex justify-center space-x-3 mb-3">
        <Button 
          variant="link" 
          className="p-0 h-auto text-xs text-neutral-500"
          onClick={() => navigate("/terms")}
        >
          Termos
        </Button>
        <span>•</span>
        <Button 
          variant="link" 
          className="p-0 h-auto text-xs text-neutral-500"
          onClick={() => navigate("/privacy")}
        >
          Privacidade
        </Button>
        <span>•</span>
        <Button 
          variant="link" 
          className="p-0 h-auto text-xs text-neutral-500"
          onClick={() => navigate("/about")}
        >
          Sobre
        </Button>
      </div>
      <p>© 2023-2025 Permuta Já. Todos os direitos reservados.</p>
      <p className="mt-2">Suporte: mardino.vilanculo@outlook.com</p>
    </div>
  );
}