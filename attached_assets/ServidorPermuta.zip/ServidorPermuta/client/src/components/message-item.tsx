import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/use-auth";

interface MessageItemProps {
  conversationId: number;
  lastMessage: any; // Type should be Message from schema
  unreadCount: number;
}

export function MessageItem({ conversationId, lastMessage, unreadCount }: MessageItemProps) {
  const [_, navigate] = useLocation();
  const { user } = useAuth();
  
  // In a real app, we would have a separate endpoint to get user info
  // For this demo, we'll use a mock query to simulate loading user data
  const { data: otherUser, isLoading } = useQuery({
    queryKey: [`/api/users/${conversationId}`],
    enabled: !!user,
    
    // Simulate data for this MVP since we don't have a real endpoint
    queryFn: async () => {
      return {
        id: conversationId,
        name: `Usuário ${conversationId}`,
        surname: "Demo",
      };
    },
  });
  
  // Format time
  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    
    if (isToday) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (date.toDateString() === yesterday.toDateString()) {
      return "Ontem";
    }
    
    return date.toLocaleDateString([], { day: '2-digit', month: '2-digit' });
  };
  
  // Truncate text
  const truncateText = (text: string, maxLength: number = 40) => {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + "...";
  };
  
  return (
    <div 
      className="p-4 border-b border-neutral-200 hover:bg-neutral-100 cursor-pointer flex items-center"
      onClick={() => navigate(`/messages/${conversationId}`)}
    >
      {isLoading ? (
        <>
          <Skeleton className="w-12 h-12 rounded-full mr-3" />
          <div className="flex-1">
            <div className="flex justify-between items-center mb-1">
              <Skeleton className="h-5 w-24" />
              <Skeleton className="h-4 w-10" />
            </div>
            <Skeleton className="h-4 w-full" />
          </div>
        </>
      ) : (
        <>
          <div className="w-12 h-12 rounded-full bg-primary/20 text-primary flex items-center justify-center mr-3">
            {otherUser?.name ? otherUser.name.charAt(0).toUpperCase() : "U"}
          </div>
          <div className="flex-1">
            <div className="flex justify-between items-center mb-1">
              <h3 className="font-medium">
                {otherUser?.name} {otherUser?.surname}
              </h3>
              <span className="text-xs text-neutral-500">
                {formatTime(lastMessage.createdAt)}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <p className="text-sm text-neutral-500 truncate">
                {truncateText(lastMessage.content)}
              </p>
              {unreadCount > 0 && (
                <span className="bg-primary w-5 h-5 rounded-full text-white text-xs flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
