import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { insertUserSchema } from "@shared/schema";
import { sectors, provinces, getDistricts } from "@/lib/locations";

interface RegisterStepsProps {
  currentStep: number;
  onNextStep: (step: number) => void;
  onPrevStep: (step: number) => void;
  onRegister: (data: z.infer<typeof insertUserSchema>) => void;
  isPending: boolean;
}

export function RegisterSteps({ 
  currentStep, 
  onNextStep, 
  onPrevStep, 
  onRegister,
  isPending
}: RegisterStepsProps) {
  const [termsAccepted, setTermsAccepted] = useState(false);
  
  const form = useForm<z.infer<typeof insertUserSchema>>({
    resolver: zodResolver(insertUserSchema),
    defaultValues: {
      name: "",
      surname: "",
      contact: "",
      password: "",
      confirmPassword: "",
      sector: "",
      salaryLevel: 1,
      grade: "",
      currentProvince: "",
      currentDistrict: "",
      desiredProvince: "",
      desiredDistrict: "",
    },
    mode: "onChange",
  });
  
  function onSubmit(data: z.infer<typeof insertUserSchema>) {
    if (currentStep < 3) {
      onNextStep(currentStep + 1);
    } else {
      onRegister(data);
    }
  }
  
  // Watch province selections to update district options
  const currentProvince = form.watch("currentProvince");
  const desiredProvince = form.watch("desiredProvince");
  
  return (
    <div className="mb-8">
      {/* Progress Indicator */}
      <div className="flex mb-8">
        <div className="flex-1">
          <div className={`w-full h-1 ${currentStep >= 1 ? "bg-primary" : "bg-neutral-200"} rounded-l-full`}></div>
          <div className={`text-xs text-center mt-1 ${currentStep >= 1 ? "text-primary font-medium" : "text-neutral-400"}`}>
            Dados Pessoais
          </div>
        </div>
        <div className="flex-1">
          <div className={`w-full h-1 ${currentStep >= 2 ? "bg-primary" : "bg-neutral-200"}`}></div>
          <div className={`text-xs text-center mt-1 ${currentStep >= 2 ? "text-primary font-medium" : "text-neutral-400"}`}>
            Profissional
          </div>
        </div>
        <div className="flex-1">
          <div className={`w-full h-1 ${currentStep >= 3 ? "bg-primary" : "bg-neutral-200"} rounded-r-full`}></div>
          <div className={`text-xs text-center mt-1 ${currentStep >= 3 ? "text-primary font-medium" : "text-neutral-400"}`}>
            Localização
          </div>
        </div>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          {/* Step 1: Personal Information */}
          <div className={currentStep === 1 ? "block" : "hidden"}>
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem className="mb-4">
                  <FormLabel>Nome</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Digite seu nome"
                      {...field}
                      className="input-field"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="surname"
              render={({ field }) => (
                <FormItem className="mb-4">
                  <FormLabel>Apelido</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Digite seu apelido"
                      {...field}
                      className="input-field"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="contact"
              render={({ field }) => (
                <FormItem className="mb-4">
                  <FormLabel>Contacto (WhatsApp)</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="+258 xx xxx xxxx"
                      {...field}
                      className="input-field"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem className="mb-4">
                  <FormLabel>Palavra-passe</FormLabel>
                  <FormControl>
                    <Input
                      type="password"
                      placeholder="Mínimo 8 caracteres"
                      {...field}
                      className="input-field"
                    />
                  </FormControl>
                  <p className="text-xs text-neutral-500 mt-1">
                    A senha deve ter pelo menos 8 caracteres, incluindo letras e números
                  </p>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="confirmPassword"
              render={({ field }) => (
                <FormItem className="mb-6">
                  <FormLabel>Confirmar Palavra-passe</FormLabel>
                  <FormControl>
                    <Input
                      type="password"
                      placeholder="Confirme sua senha"
                      {...field}
                      className="input-field"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              className="primary-button"
            >
              Continuar
            </Button>
          </div>
          
          {/* Step 2: Professional Information */}
          <div className={currentStep === 2 ? "block" : "hidden"}>
            <FormField
              control={form.control}
              name="sector"
              render={({ field }) => (
                <FormItem className="mb-4">
                  <FormLabel>Sector</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="input-field mb-0">
                        <SelectValue placeholder="Selecione o Sector" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {sectors.map(sector => (
                        <SelectItem key={sector.value} value={sector.value}>
                          {sector.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="salaryLevel"
              render={({ field }) => (
                <FormItem className="mb-4">
                  <FormLabel>Nível Salarial</FormLabel>
                  <Select
                    onValueChange={(value) => field.onChange(parseInt(value))}
                    defaultValue={field.value?.toString()}
                  >
                    <FormControl>
                      <SelectTrigger className="input-field mb-0">
                        <SelectValue placeholder="Selecione o Nível" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {Array.from({ length: 12 }, (_, i) => i + 1).map(level => (
                        <SelectItem key={level} value={level.toString()}>
                          Nível {level}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="grade"
              render={({ field }) => (
                <FormItem className="mb-6">
                  <FormLabel>Escalão</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="input-field mb-0">
                        <SelectValue placeholder="Selecione o Escalão" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="A">Escalão A</SelectItem>
                      <SelectItem value="B">Escalão B</SelectItem>
                      <SelectItem value="C">Escalão C</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="flex space-x-4">
              <Button 
                type="button" 
                variant="outline" 
                className="flex-1" 
                onClick={() => onPrevStep(1)}
              >
                Voltar
              </Button>
              <Button 
                type="submit" 
                className="primary-button flex-1"
              >
                Continuar
              </Button>
            </div>
          </div>
          
          {/* Step 3: Location Information */}
          <div className={currentStep === 3 ? "block" : "hidden"}>
            <FormField
              control={form.control}
              name="currentProvince"
              render={({ field }) => (
                <FormItem className="mb-4">
                  <FormLabel>Província Atual</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="input-field mb-0">
                        <SelectValue placeholder="Selecione a Província" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {provinces.map(province => (
                        <SelectItem key={province.value} value={province.value}>
                          {province.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="currentDistrict"
              render={({ field }) => (
                <FormItem className="mb-6">
                  <FormLabel>Distrito Atual</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    disabled={!currentProvince}
                  >
                    <FormControl>
                      <SelectTrigger className="input-field mb-0">
                        <SelectValue placeholder="Selecione o Distrito" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {currentProvince && getDistricts(currentProvince).map(district => (
                        <SelectItem key={district.value} value={district.value}>
                          {district.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="desiredProvince"
              render={({ field }) => (
                <FormItem className="mb-4">
                  <FormLabel>Província Pretendida</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger className="input-field mb-0">
                        <SelectValue placeholder="Selecione a Província" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {provinces.map(province => (
                        <SelectItem key={province.value} value={province.value}>
                          {province.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="desiredDistrict"
              render={({ field }) => (
                <FormItem className="mb-6">
                  <FormLabel>Distrito Pretendido</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    disabled={!desiredProvince}
                  >
                    <FormControl>
                      <SelectTrigger className="input-field mb-0">
                        <SelectValue placeholder="Selecione o Distrito" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {desiredProvince && getDistricts(desiredProvince).map(district => (
                        <SelectItem key={district.value} value={district.value}>
                          {district.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="mb-6 flex items-center">
              <Checkbox 
                id="termsAccepted" 
                className="mr-2 h-4 w-4 text-primary data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground"
                checked={termsAccepted}
                onCheckedChange={(checked) => {
                  setTermsAccepted(checked as boolean);
                }}
              />
              <label htmlFor="termsAccepted" className="text-sm text-neutral-600">
                Aceito os <a href="#" className="text-secondary">termos e condições</a>
              </label>
            </div>
            
            <div className="flex space-x-4">
              <Button 
                type="button" 
                variant="outline" 
                className="flex-1" 
                onClick={() => onPrevStep(2)}
              >
                Voltar
              </Button>
              <Button 
                type="submit" 
                className="primary-button flex-1"
                disabled={!termsAccepted || isPending}
              >
                {isPending ? "Registrando..." : "Registrar"}
              </Button>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
}
