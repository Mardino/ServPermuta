import { useLocation } from "wouter";
import { Home, Search, MessageSquare, User } from "lucide-react";

type Tab = "home" | "search" | "messages" | "account";

interface BottomNavigationProps {
  activeTab: Tab;
}

export function BottomNavigation({ activeTab }: BottomNavigationProps) {
  const [_, navigate] = useLocation();
  
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white shadow-[0_-2px_10px_rgba(0,0,0,0.05)] z-10">
      <div className="w-full max-w-md mx-auto flex justify-around items-center">
        <a 
          href="#" 
          className={`flex flex-col items-center py-3 px-4 ${
            activeTab === "home" ? "text-primary" : "text-neutral-500"
          }`}
          onClick={(e) => {
            e.preventDefault();
            navigate("/home");
          }}
        >
          <Home className="h-5 w-5" />
          <span className="text-xs mt-1">Início</span>
        </a>
        
        <a 
          href="#" 
          className={`flex flex-col items-center py-3 px-4 ${
            activeTab === "search" ? "text-primary" : "text-neutral-500"
          }`}
          onClick={(e) => {
            e.preventDefault();
            navigate("/search");
          }}
        >
          <Search className="h-5 w-5" />
          <span className="text-xs mt-1">Pesquisar</span>
        </a>
        
        <a 
          href="#" 
          className={`flex flex-col items-center py-3 px-4 ${
            activeTab === "messages" ? "text-primary" : "text-neutral-500"
          }`}
          onClick={(e) => {
            e.preventDefault();
            navigate("/messages");
          }}
        >
          <MessageSquare className="h-5 w-5" />
          <span className="text-xs mt-1">Mensagens</span>
        </a>
        
        <a 
          href="#" 
          className={`flex flex-col items-center py-3 px-4 ${
            activeTab === "account" ? "text-primary" : "text-neutral-500"
          }`}
          onClick={(e) => {
            e.preventDefault();
            navigate("/profile");
          }}
        >
          <User className="h-5 w-5" />
          <span className="text-xs mt-1">Perfil</span>
        </a>
      </div>
    </nav>
  );
}
