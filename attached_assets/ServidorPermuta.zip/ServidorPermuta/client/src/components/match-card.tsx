import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Info, MessageSquare } from "lucide-react";

interface MatchCardProps {
  match: any; // Type should be User from schema, but without password
}

export function MatchCard({ match }: MatchCardProps) {
  const [_, navigate] = useLocation();
  
  return (
    <Card className="p-4 rounded-lg shadow-sm mb-4">
      <div className="flex mb-3">
        <div className="w-14 h-14 rounded-full bg-primary/20 text-primary flex items-center justify-center mr-3">
          {match.name ? match.name.charAt(0).toUpperCase() : "U"}
        </div>
        <div>
          <h3 className="font-medium">{match.name} {match.surname}</h3>
          <p className="text-sm text-neutral-500">
            Nível {match.salaryLevel}, Escalão {match.grade}
          </p>
          <div className="flex items-center mt-1">
            <span className="text-xs bg-neutral-200 text-neutral-700 px-2 py-0.5 rounded-full">
              {match.sector}
            </span>
          </div>
        </div>
      </div>
      
      <div className="bg-neutral-100 rounded-lg p-3 mb-3">
        <div className="flex">
          <div className="w-1/2 pr-2">
            <p className="text-xs text-neutral-500">Atual</p>
            <p className="text-sm font-medium">
              {match.currentProvince}, {match.currentDistrict}
            </p>
          </div>
          <div className="w-1/2 pl-2 border-l border-neutral-200">
            <p className="text-xs text-neutral-500">Pretendido</p>
            <p className="text-sm font-medium">
              {match.desiredProvince}, {match.desiredDistrict}
            </p>
          </div>
        </div>
      </div>
      
      <div className="flex space-x-2">
        <Button 
          variant="outline" 
          className="flex-1 py-2 text-secondary font-medium flex justify-center items-center"
        >
          <Info className="h-4 w-4 mr-1" />
          Detalhes
        </Button>
        <Button 
          className="flex-1 py-2 bg-secondary text-white rounded-lg font-medium flex justify-center items-center"
          onClick={() => navigate(`/messages/${match.id}`)}
        >
          <MessageSquare className="h-4 w-4 mr-1" />
          Contactar
        </Button>
      </div>
    </Card>
  );
}
