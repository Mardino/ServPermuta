import { z } from "zod";

// Password validation
export const passwordSchema = z.string()
  .min(8, "A senha deve ter pelo menos 8 caracteres")
  .regex(/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/, 
    "A senha deve conter pelo menos uma letra e um número");

// Contact (WhatsApp) validation
export const contactSchema = z.string()
  .min(9, "Contacto deve ter pelo menos 9 dígitos")
  .regex(/^\+?[0-9]{9,13}$/, "Formato de contacto inválido");

// Form validation for profile
export const profileFormSchema = z.object({
  name: z.string().min(2, "Nome deve ter pelo menos 2 caracteres"),
  surname: z.string().min(2, "Apelido deve ter pelo menos 2 caracteres"),
  contact: contactSchema,
  sector: z.string().min(1, "Selecione um sector"),
  salaryLevel: z.number().min(1).max(12),
  grade: z.string().min(1, "Selecione um escalão"),
  currentProvince: z.string().min(1, "Selecione a província atual"),
  currentDistrict: z.string().min(1, "Selecione o distrito atual"),
  desiredProvince: z.string().min(1, "Selecione a província pretendida"),
  desiredDistrict: z.string().min(1, "Selecione o distrito pretendido"),
});
