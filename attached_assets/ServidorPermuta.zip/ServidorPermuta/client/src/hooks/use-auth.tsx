import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";

interface User {
  id: number;
  name: string;
  surname: string;
  contact: string;
  sector: string;
  salaryLevel: number;
  grade: string;
  currentProvince: string;
  currentDistrict: string;
  desiredProvince: string;
  desiredDistrict: string;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  login: (user: User) => void;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  login: () => {},
  logout: () => {},
  isLoading: false,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [_, navigate] = useLocation();
  
  const { isLoading, refetch } = useQuery({
    queryKey: ["/api/auth/me"],
    queryFn: async () => {
      const response = await fetch("/api/auth/me", {
        credentials: "include",
      });
      
      if (!response.ok) {
        if (response.status === 401) {
          return null;
        }
        throw new Error("Failed to fetch user data");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      if (data) {
        setUser(data);
      } else {
        // If on a protected route, redirect to login
        const protectedRoutes = ["/home", "/search", "/messages", "/profile"];
        const path = window.location.pathname;
        
        if (protectedRoutes.some(route => path.startsWith(route))) {
          navigate("/login");
        }
      }
    },
    onError: () => {
      setUser(null);
    },
  });
  
  const login = (userData: User) => {
    setUser(userData);
    navigate("/home");
  };
  
  const logout = () => {
    setUser(null);
    navigate("/login");
  };
  
  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
