import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Bell } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SquareSplitHorizontal, Edit } from "lucide-react";
import { BottomNavigation } from "@/components/bottom-navigation";
import { MatchCard } from "@/components/match-card";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const { user } = useAuth();
  const [_, navigate] = useLocation();
  
  const { data: matches, isLoading } = useQuery({
    queryKey: ["/api/matches"],
    enabled: !!user,
  });

  if (!user) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p>Redirecionando para login...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-100 pb-20">
      <div className="bg-white shadow-sm">
        <div className="w-full max-w-md mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center">
            <SquareSplitHorizontal className="text-primary h-6 w-6 mr-2" />
            <h1 className="text-lg font-medium">Permuta Já</h1>
          </div>
          <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => {}}>
            <Bell className="h-5 w-5 text-neutral-600" />
          </Button>
        </div>
      </div>
      
      <div className="w-full max-w-md mx-auto px-6 py-4">
        {/* User Info Card */}
        <Card className="p-4 mb-6">
          <div className="mb-3 flex justify-between items-center">
            <h2 className="text-lg font-medium">Bem-vindo, {user.name}!</h2>
            <span className="text-xs bg-secondary text-white px-2 py-1 rounded-full">
              Nível {user.salaryLevel}
            </span>
          </div>
          
          <div className="bg-neutral-100 rounded-lg p-4 mb-4">
            <div className="flex mb-2">
              <div className="w-1/2 pr-2">
                <p className="text-xs text-neutral-500">Atual</p>
                <p className="text-sm font-medium">
                  {user.currentProvince}, {user.currentDistrict}
                </p>
              </div>
              <div className="w-1/2 pl-2 border-l border-neutral-200">
                <p className="text-xs text-neutral-500">Pretendido</p>
                <p className="text-sm font-medium">
                  {user.desiredProvince}, {user.desiredDistrict}
                </p>
              </div>
            </div>
            <div className="flex items-center">
              <div className="flex-1 h-1 bg-primary/30 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary" 
                  style={{ width: isLoading ? "0%" : `${Math.min(100, (matches?.length || 0) * 33)}%` }}
                ></div>
              </div>
              <p className="ml-2 text-xs text-neutral-500">
                {isLoading ? "..." : `${matches?.length || 0} correspondências`}
              </p>
            </div>
          </div>
          
          <Button 
            variant="ghost" 
            className="w-full py-2 text-secondary text-sm font-medium flex justify-center items-center"
            onClick={() => navigate("/profile")}
          >
            <Edit className="h-4 w-4 mr-1" />
            Editar Perfil
          </Button>
        </Card>
        
        {/* Match Results */}
        <h2 className="text-lg font-medium mb-4">Correspondências Encontradas</h2>
        
        {isLoading ? (
          // Loading skeletons
          <>
            {[1, 2, 3].map((i) => (
              <Card key={i} className="p-4 mb-4">
                <div className="flex mb-3">
                  <Skeleton className="w-14 h-14 rounded-full mr-3" />
                  <div className="flex-1">
                    <Skeleton className="h-5 w-32 mb-1" />
                    <Skeleton className="h-4 w-24 mb-1" />
                    <Skeleton className="h-5 w-20" />
                  </div>
                </div>
                <Skeleton className="h-20 w-full mb-3" />
                <div className="flex space-x-2">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              </Card>
            ))}
          </>
        ) : matches && matches.length > 0 ? (
          // Match cards
          <div id="matchesList">
            {matches.map((match) => (
              <MatchCard key={match.id} match={match} />
            ))}
          </div>
        ) : (
          // No matches state
          <Card className="p-6 rounded-lg text-center mb-6">
            <div className="w-16 h-16 bg-neutral-200 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-8 w-8 text-neutral-500"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            </div>
            <h3 className="text-lg font-medium mb-2">Nenhuma correspondência</h3>
            <p className="text-neutral-600 mb-4">
              Nós notificaremos quando encontrarmos correspondências para você.
            </p>
            <Button variant="outline" onClick={() => navigate("/profile")}>
              Ajustar Preferências
            </Button>
          </Card>
        )}
      </div>
      
      <BottomNavigation activeTab="home" />
    </div>
  );
}
