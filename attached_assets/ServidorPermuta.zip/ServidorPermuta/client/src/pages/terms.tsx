import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function Terms() {
  const [_, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-neutral-100">
      <div className="bg-white shadow-sm">
        <div className="w-full max-w-md mx-auto px-6 py-4">
          <div className="flex items-center">
            <Button
              variant="ghost"
              className="mr-2 p-0 h-9 w-9"
              onClick={() => navigate("/")}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-lg font-medium">Termos e Condições</h1>
          </div>
        </div>
      </div>
      
      <div className="w-full max-w-md mx-auto px-6 py-4">
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-medium mb-4">Termos de Uso</h2>
          <p className="text-sm text-neutral-600 mb-4">
            Última atualização: Maio de 2023
          </p>
          
          <div className="prose prose-sm text-neutral-700">
            <p className="mb-4">
              Bem-vindo ao Permuta Já. Estes Termos de Uso regem seu acesso e uso do aplicativo Permuta Já, incluindo quaisquer conteúdos, funcionalidades e serviços oferecidos através do aplicativo.
            </p>
            
            <h3 className="text-lg font-medium mt-6 mb-2">1. Aceitação dos Termos</h3>
            <p className="mb-4">
              Ao usar o Permuta Já, você concorda com estes Termos de Uso. Se não concordar com estes termos, não deve usar o aplicativo.
            </p>
            
            <h3 className="text-lg font-medium mt-6 mb-2">2. Elegibilidade</h3>
            <p className="mb-4">
              O Permuta Já destina-se a funcionários públicos de Moçambique que estão interessados em realizar permuta de local de trabalho. Para usar o aplicativo, você deve ser maior de 18 anos e um funcionário público devidamente registrado.
            </p>
            
            <h3 className="text-lg font-medium mt-6 mb-2">3. Cadastro e Conta</h3>
            <p className="mb-4">
              Ao se cadastrar no Permuta Já, você concorda em fornecer informações precisas, atualizadas e completas. Você é responsável por manter a confidencialidade da sua senha e por todas as atividades que ocorrem em sua conta.
            </p>
            
            <h3 className="text-lg font-medium mt-6 mb-2">4. Uso do Serviço</h3>
            <p className="mb-4">
              Você concorda em usar o Permuta Já apenas para fins legais e de acordo com estes Termos. Você não deve:
            </p>
            <ul className="list-disc pl-5 mb-4">
              <li>Usar o aplicativo para qualquer finalidade ilegal ou não autorizada</li>
              <li>Postar informações falsas ou enganosas</li>
              <li>Interferir com a segurança do aplicativo</li>
              <li>Distribuir vírus ou qualquer outro código malicioso</li>
              <li>Assediar, intimidar ou ameaçar outros usuários</li>
            </ul>
            
            <h3 className="text-lg font-medium mt-6 mb-2">5. Privacidade</h3>
            <p className="mb-4">
              Nossas práticas de privacidade são descritas em nossa Política de Privacidade. Ao usar o Permuta Já, você concorda com a coleta e uso de suas informações conforme descrito nessa política.
            </p>
            
            <h3 className="text-lg font-medium mt-6 mb-2">6. Alterações nos Termos</h3>
            <p className="mb-4">
              Podemos atualizar estes Termos periodicamente. A versão mais recente estará sempre disponível no aplicativo. Ao continuar a usar o Permuta Já após as alterações, você concorda com os novos termos.
            </p>
            
            <h3 className="text-lg font-medium mt-6 mb-2">7. Encerramento</h3>
            <p className="mb-4">
              Podemos encerrar ou suspender sua conta e acesso ao Permuta Já por violação destes Termos ou por qualquer outro motivo, a nosso critério exclusivo.
            </p>
            
            <h3 className="text-lg font-medium mt-6 mb-2">8. Limitação de Responsabilidade</h3>
            <p className="mb-4">
              O Permuta Já e seus criadores não serão responsáveis por quaisquer danos diretos, indiretos, incidentais, consequenciais ou punitivos resultantes do uso ou incapacidade de usar o aplicativo.
            </p>
            
            <h3 className="text-lg font-medium mt-6 mb-2">9. Lei Aplicável</h3>
            <p className="mb-4">
              Estes Termos são regidos pelas leis de Moçambique. Qualquer disputa relacionada a estes Termos será submetida à jurisdição exclusiva dos tribunais de Moçambique.
            </p>
            
            <h3 className="text-lg font-medium mt-6 mb-2">10. Contato</h3>
            <p className="mb-4">
              Se você tiver dúvidas sobre estes Termos de Uso, entre em contato conosco pelo email: termos@permutaja.co.mz.
            </p>
          </div>
          
          <Button 
            className="w-full mt-6" 
            onClick={() => navigate("/")}
          >
            Voltar
          </Button>
        </Card>
      </div>
    </div>
  );
}