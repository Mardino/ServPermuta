import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { BottomNavigation } from "@/components/bottom-navigation";
import { useAuth } from "@/hooks/use-auth";
import { sectors, provinces, getDistricts } from "@/lib/locations";

export default function Search() {
  const { user } = useAuth();
  const [sector, setSector] = useState("");
  const [salaryLevel, setSalaryLevel] = useState("");
  const [province, setProvince] = useState("");
  
  const { data: searchResults, refetch, isLoading } = useQuery({
    queryKey: ["/api/search", { 
      sector: sector !== "todos" ? sector : undefined, 
      salaryLevel: salaryLevel !== "todos" ? parseInt(salaryLevel) : undefined, 
      province: province !== "todas" ? province : undefined 
    }],
    enabled: false,
  });
  
  const handleSearch = async () => {
    await refetch();
  };
  
  if (!user) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p>Redirecionando para login...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-100 pb-20">
      <div className="bg-white shadow-sm">
        <div className="w-full max-w-md mx-auto px-6 py-4">
          <h1 className="text-lg font-medium">Pesquisar</h1>
        </div>
      </div>
      
      <div className="w-full max-w-md mx-auto px-6 py-4">
        <Card className="p-4 mb-6">
          <h2 className="text-lg font-medium mb-4">Filtros de Pesquisa</h2>
          
          <div className="mb-4">
            <label className="block text-neutral-600 text-sm mb-2" htmlFor="searchSector">
              Sector
            </label>
            <Select value={sector} onValueChange={setSector}>
              <SelectTrigger className="input-field mb-0">
                <SelectValue placeholder="Todos os Sectores" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os Sectores</SelectItem>
                {sectors.map(s => (
                  <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="mb-4">
            <label className="block text-neutral-600 text-sm mb-2" htmlFor="searchSalaryLevel">
              Nível Salarial
            </label>
            <Select value={salaryLevel} onValueChange={setSalaryLevel}>
              <SelectTrigger className="input-field mb-0">
                <SelectValue placeholder="Todos os Níveis" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os Níveis</SelectItem>
                {Array.from({ length: 12 }, (_, i) => i + 1).map(level => (
                  <SelectItem key={level} value={String(level)}>Nível {level}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="mb-4">
            <label className="block text-neutral-600 text-sm mb-2" htmlFor="searchProvince">
              Província
            </label>
            <Select value={province} onValueChange={setProvince}>
              <SelectTrigger className="input-field mb-0">
                <SelectValue placeholder="Todas as Províncias" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas as Províncias</SelectItem>
                {provinces.map(p => (
                  <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <Button className="primary-button" onClick={handleSearch} disabled={isLoading}>
            {isLoading ? "Buscando..." : "Buscar"}
          </Button>
        </Card>
        
        <h2 className="text-lg font-medium mb-4">Resultados</h2>
        
        {/* Search Results */}
        <div id="searchResults">
          {/* People collaborating in workplace */}
          <Card className="mb-6 rounded-lg overflow-hidden shadow-sm">
            <div className="h-40 bg-gradient-to-r from-primary/70 to-secondary/70 flex items-center justify-center">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-24 w-24 text-white/80" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  strokeWidth={1} 
                  d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" 
                />
              </svg>
            </div>
            <div className="p-4">
              <h3 className="text-lg font-medium mb-2">Colabore com outros profissionais</h3>
              <p className="text-neutral-600 mb-4">
                Conecte-se com outros funcionários públicos e encontre a permuta ideal para sua carreira.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="text-xs bg-neutral-200 text-neutral-700 px-2 py-1 rounded-full">Educação</span>
                <span className="text-xs bg-neutral-200 text-neutral-700 px-2 py-1 rounded-full">Saúde</span>
                <span className="text-xs bg-neutral-200 text-neutral-700 px-2 py-1 rounded-full">Agricultura</span>
                <span className="text-xs bg-neutral-200 text-neutral-700 px-2 py-1 rounded-full">+4 sectores</span>
              </div>
            </div>
          </Card>
          
          {/* Office workplace environment */}
          <Card className="mb-6 rounded-lg overflow-hidden shadow-sm">
            <div className="h-40 bg-gradient-to-r from-secondary/70 to-primary/70 flex items-center justify-center">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-24 w-24 text-white/80" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  strokeWidth={1} 
                  d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" 
                />
              </svg>
            </div>
            <div className="p-4">
              <h3 className="text-lg font-medium mb-2">Encontre seu ambiente ideal</h3>
              <p className="text-neutral-600 mb-4">
                Busque oportunidades de permuta em diferentes localidades e ambientes de trabalho.
              </p>
              <Button className="w-full py-2 bg-secondary text-white rounded-lg font-medium">
                Ver Oportunidades
              </Button>
            </div>
          </Card>
        </div>
      </div>
      
      <BottomNavigation activeTab="search" />
    </div>
  );
}
