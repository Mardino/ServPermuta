import { useState, useEffect, useRef } from "react";
import { useLocation, useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/use-auth";
import { ArrowLeft, Send } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest } from "@/lib/queryClient";
import { insertMessageSchema } from "@shared/schema";
import { z } from "zod";

export default function Chat() {
  const { id } = useParams();
  const { user } = useAuth();
  const [_, navigate] = useLocation();
  const [newMessage, setNewMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();
  
  const receiverId = parseInt(id);
  
  const { data: conversation, isLoading } = useQuery({
    queryKey: [`/api/messages/${receiverId}`],
    enabled: !!user && !isNaN(receiverId),
    refetchInterval: 5000, // Poll for new messages every 5 seconds
  });
  
  const { data: receiverData, isLoading: isLoadingReceiver } = useQuery({
    queryKey: [`/api/users/${receiverId}`],
    enabled: !!user && !isNaN(receiverId),
  });
  
  const sendMessageMutation = useMutation({
    mutationFn: async (data: z.infer<typeof insertMessageSchema>) => {
      const response = await apiRequest("POST", "/api/messages", data);
      return response.json();
    },
    onSuccess: () => {
      setNewMessage("");
      queryClient.invalidateQueries({ queryKey: [`/api/messages/${receiverId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
    },
  });
  
  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    
    sendMessageMutation.mutate({
      receiverId,
      content: newMessage.trim(),
    });
  };
  
  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conversation]);
  
  if (!user) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p>Redirecionando para login...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-100 flex flex-col">
      <div className="bg-white shadow-sm">
        <div className="w-full max-w-md mx-auto px-6 py-4 flex items-center">
          <Button
            variant="ghost"
            size="icon"
            className="mr-2 p-0 h-9 w-9"
            onClick={() => navigate("/messages")}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          
          {isLoadingReceiver ? (
            <div className="flex items-center">
              <Skeleton className="w-10 h-10 rounded-full mr-3" />
              <Skeleton className="h-5 w-24" />
            </div>
          ) : (
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-full bg-primary/20 text-primary flex items-center justify-center mr-3">
                {receiverData?.name ? receiverData.name.charAt(0).toUpperCase() : "U"}
              </div>
              <h1 className="text-lg font-medium">
                {receiverData?.name ? `${receiverData.name} ${receiverData.surname}` : "Usuário"}
              </h1>
            </div>
          )}
        </div>
      </div>
      
      <div className="flex-1 w-full max-w-md mx-auto px-6 py-4 overflow-y-auto">
        {isLoading ? (
          // Loading skeletons
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className={`flex ${i % 2 === 0 ? "justify-start" : "justify-end"}`}>
                <Skeleton className={`h-12 ${i % 2 === 0 ? "w-2/3" : "w-1/2"} rounded-lg`} />
              </div>
            ))}
          </div>
        ) : conversation && conversation.length > 0 ? (
          // Messages
          <div className="space-y-4">
            {conversation.map((message) => (
              <div key={message.id} className={`flex ${message.senderId === user.id ? "justify-end" : "justify-start"}`}>
                <div 
                  className={`max-w-xs p-3 rounded-lg ${
                    message.senderId === user.id 
                      ? "bg-secondary text-white rounded-br-none" 
                      : "bg-white text-neutral-800 rounded-bl-none"
                  }`}
                >
                  <p>{message.content}</p>
                  <span className={`text-xs block text-right mt-1 ${
                    message.senderId === user.id ? "text-white/70" : "text-neutral-500"
                  }`}>
                    {new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        ) : (
          // Empty state
          <div className="flex flex-col items-center justify-center h-full">
            <div className="w-16 h-16 bg-neutral-200 rounded-full flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-8 w-8 text-neutral-500"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                />
              </svg>
            </div>
            <p className="text-neutral-600">Nenhuma mensagem. Comece a conversar!</p>
          </div>
        )}
      </div>
      
      <div className="bg-white border-t border-neutral-200 p-4">
        <div className="w-full max-w-md mx-auto flex items-center">
          <Input
            type="text"
            placeholder="Digite sua mensagem..."
            className="flex-1 bg-neutral-100 border-0 rounded-lg mr-2"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
          />
          <Button 
            size="icon"
            className="bg-secondary text-white h-10 w-10 rounded-full"
            onClick={handleSendMessage}
            disabled={sendMessageMutation.isPending || !newMessage.trim()}
          >
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
