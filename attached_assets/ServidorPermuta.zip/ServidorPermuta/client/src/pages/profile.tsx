import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BottomNavigation } from "@/components/bottom-navigation";
import { UserProfileHeader } from "@/components/user-profile-header";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { 
  Bell, 
  Lock, 
  HelpCircle, 
  Info, 
  ChevronRight,
  LogOut
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function Profile() {
  const { user, logout } = useAuth();
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const logoutMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/auth/logout", {});
      return response.json();
    },
    onSuccess: () => {
      logout();
      toast({
        title: "Logout bem-sucedido",
        description: "Você saiu da sua conta.",
      });
      navigate("/login");
    },
    onError: (error) => {
      toast({
        title: "Erro ao sair",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  if (!user) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p>Redirecionando para login...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-100 pb-20">
      <div className="bg-white shadow-sm">
        <div className="w-full max-w-md mx-auto px-6 py-4">
          <h1 className="text-lg font-medium">Perfil</h1>
        </div>
      </div>
      
      <div className="w-full max-w-md mx-auto px-6 py-4">
        <UserProfileHeader user={user} />
        
        <Card className="rounded-lg shadow-sm mb-6">
          <h3 className="p-4 border-b border-neutral-200 font-medium">Informações da Permuta</h3>
          
          <div className="p-4">
            <div className="flex mb-4">
              <div className="w-1/2 pr-4">
                <p className="text-sm text-neutral-500 mb-1">Localização Atual</p>
                <p className="font-medium">{user.currentProvince}, {user.currentDistrict}</p>
              </div>
              <div className="w-1/2">
                <p className="text-sm text-neutral-500 mb-1">Localização Pretendida</p>
                <p className="font-medium">{user.desiredProvince}, {user.desiredDistrict}</p>
              </div>
            </div>
            
            <div className="flex mb-1">
              <div className="w-1/2 pr-4">
                <p className="text-sm text-neutral-500 mb-1">Sector</p>
                <p className="font-medium">{user.sector}</p>
              </div>
              <div className="w-1/2">
                <p className="text-sm text-neutral-500 mb-1">Contacto</p>
                <p className="font-medium">{user.contact}</p>
              </div>
            </div>
          </div>
        </Card>
        
        <Card className="rounded-lg shadow-sm mb-6">
          <Button 
            variant="ghost" 
            className="w-full p-4 border-b border-neutral-200 hover:bg-neutral-100 justify-start text-base font-normal rounded-none h-auto"
            onClick={() => navigate("/terms")}
          >
            <div className="flex justify-between items-center w-full">
              <div className="flex items-center">
                <Bell className="text-neutral-500 mr-3 h-5 w-5" />
                <span>Termos e Políticas</span>
              </div>
              <ChevronRight className="text-neutral-500 h-5 w-5" />
            </div>
          </Button>
          
          <Button 
            variant="ghost" 
            className="w-full p-4 border-b border-neutral-200 hover:bg-neutral-100 justify-start text-base font-normal rounded-none h-auto"
            onClick={() => navigate("/profile/change-password")}
          >
            <div className="flex justify-between items-center w-full">
              <div className="flex items-center">
                <Lock className="text-neutral-500 mr-3 h-5 w-5" />
                <span>Alterar Senha</span>
              </div>
              <ChevronRight className="text-neutral-500 h-5 w-5" />
            </div>
          </Button>
          
          <Button 
            variant="ghost" 
            className="w-full p-4 border-b border-neutral-200 hover:bg-neutral-100 justify-start text-base font-normal rounded-none h-auto"
            onClick={() => navigate("/profile/delete-account")}
          >
            <div className="flex justify-between items-center w-full">
              <div className="flex items-center">
                <HelpCircle className="text-neutral-500 mr-3 h-5 w-5" />
                <span>Excluir Conta</span>
              </div>
              <ChevronRight className="text-neutral-500 h-5 w-5" />
            </div>
          </Button>
          
          <Button 
            variant="ghost" 
            className="w-full p-4 hover:bg-neutral-100 justify-start text-base font-normal rounded-t-none h-auto"
            onClick={() => navigate("/about")}
          >
            <div className="flex justify-between items-center w-full">
              <div className="flex items-center">
                <Info className="text-neutral-500 mr-3 h-5 w-5" />
                <span>Sobre o App</span>
              </div>
              <ChevronRight className="text-neutral-500 h-5 w-5" />
            </div>
          </Button>
        </Card>
        
        <Button 
          variant="ghost" 
          className="w-full py-3 text-primary font-medium"
          onClick={handleLogout}
          disabled={logoutMutation.isPending}
        >
          {logoutMutation.isPending ? "Saindo..." : "Sair da Conta"}
        </Button>
      </div>
      
      <BottomNavigation activeTab="account" />
    </div>
  );
}
