import { useState } from "react";
import { useLocation } from "wouter";
import { SquareSplitHorizontal } from "lucide-react";
import { SupportFooter } from "@/components/support-footer";

export default function Welcome() {
  const [_, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-white">
      <div className="w-full max-w-md mx-auto px-6 py-10 flex flex-col items-center justify-center min-h-screen">
        <div className="w-24 h-24 mb-8 rounded-full bg-primary flex items-center justify-center">
          <SquareSplitHorizontal className="text-white h-10 w-10" />
        </div>
        
        <h1 className="text-3xl font-medium text-neutral-800 mb-6 text-center">
          Bem-vindo ao Permuta Já!
        </h1>
        
        <p className="text-neutral-600 mb-8 text-center">
          Siga o tutorial para começar a usar o app:
        </p>
        
        <div className="w-full max-w-xs mb-6">
          <div className="flex items-start mb-6">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center mr-4">
              1
            </div>
            <div>
              <p className="text-neutral-600">
                Faça login utilizando o seu número de WhatsApp
              </p>
            </div>
          </div>
          
          <div className="flex items-start mb-6">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center mr-4">
              2
            </div>
            <div>
              <p className="text-neutral-600">
                Cadastre seu perfil com suas informações profissionais
              </p>
            </div>
          </div>
          
          <div className="flex items-start mb-10">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center mr-4">
              3
            </div>
            <div>
              <p className="text-neutral-600">
                Encontre e conecte-se com funcionários para permutas
              </p>
            </div>
          </div>
        </div>
        
        <button 
          className="primary-button"
          onClick={() => navigate("/login")}
        >
          Começar
        </button>
        
        <div className="mt-12">
          <SupportFooter />
        </div>
      </div>
    </div>
  );
}