import { useState } from "react";
import { useLocation } from "wouter";
import { SquareSplitHorizontal } from "lucide-react";
import { SupportFooter } from "@/components/support-footer";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { loginSchema } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";

export default function Login() {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const { login } = useAuth();
  
  const form = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      contact: "",
      password: "",
    },
  });

  const loginMutation = useMutation({
    mutationFn: async (data: z.infer<typeof loginSchema>) => {
      const response = await apiRequest("POST", "/api/auth/login", data);
      return response.json();
    },
    onSuccess: (data) => {
      login(data);
      toast({
        title: "Login bem-sucedido",
        description: "Bem-vindo de volta ao Permuta Já!",
      });
      navigate("/home");
    },
    onError: (error) => {
      toast({
        title: "Erro ao fazer login",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function onSubmit(data: z.infer<typeof loginSchema>) {
    loginMutation.mutate(data);
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="w-full max-w-md mx-auto px-6 py-10 flex flex-col items-center min-h-screen">
        <div className="w-full pt-6 pb-10 flex justify-center">
          <div className="flex items-center">
            <SquareSplitHorizontal className="text-primary h-8 w-8 mr-3" />
            <h1 className="text-2xl font-medium text-neutral-800">Permuta Já</h1>
          </div>
        </div>
        
        <div className="w-full">
          <h2 className="text-2xl font-medium text-neutral-800 mb-8 text-center">Entrar</h2>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="mb-8 space-y-6">
              <FormField
                control={form.control}
                name="contact"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Contacto (WhatsApp)</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="+258 xx xxx xxxx"
                        {...field}
                        className="input-field"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Palavra-passe</FormLabel>
                    <FormControl>
                      <Input
                        type="password"
                        placeholder="Digite sua senha"
                        {...field}
                        className="input-field"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="text-right">
                <Button
                  type="button"
                  variant="link"
                  className="text-secondary p-0 h-auto font-normal"
                  onClick={() => navigate("/forgot-password")}
                >
                  Esqueceu a palavra-passe?
                </Button>
              </div>
              
              <Button 
                type="submit" 
                className="primary-button"
                disabled={loginMutation.isPending}
              >
                {loginMutation.isPending ? "Entrando..." : "Entrar"}
              </Button>
            </form>
          </Form>
          
          <div className="text-center">
            <p className="text-neutral-600 mb-4">Não tem uma conta?</p>
            <Button
              type="button"
              variant="outline"
              className="outline-button"
              onClick={() => navigate("/register")}
            >
              Criar Nova Conta
            </Button>
          </div>
          
          <div className="mt-12">
            <SupportFooter />
          </div>
        </div>
      </div>
    </div>
  );
}
