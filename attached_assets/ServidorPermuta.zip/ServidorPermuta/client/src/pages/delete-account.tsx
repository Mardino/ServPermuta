import { useState } from "react";
import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";

export default function DeleteAccount() {
  const { user, logout } = useAuth();
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const [confirmText, setConfirmText] = useState("");
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);

  const deleteAccountMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("DELETE", "/api/users/account", {});
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Conta excluída",
        description: "Sua conta foi excluída com sucesso.",
      });
      logout();
      navigate("/");
    },
    onError: (error) => {
      toast({
        title: "Erro ao excluir conta",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDeleteAccount = () => {
    if (confirmText === "EXCLUIR") {
      deleteAccountMutation.mutate();
      setShowConfirmDialog(false);
    }
  };

  if (!user) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p>Redirecionando para login...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-100">
      <div className="bg-white shadow-sm">
        <div className="w-full max-w-md mx-auto px-6 py-4">
          <div className="flex items-center">
            <Button
              variant="ghost"
              className="mr-2 p-0 h-9 w-9"
              onClick={() => navigate("/profile")}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-lg font-medium">Excluir Conta</h1>
          </div>
        </div>
      </div>

      <div className="w-full max-w-md mx-auto px-6 py-4">
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-medium mb-4">Excluir conta permanentemente</h2>
          
          <div className="rounded-lg bg-red-50 p-4 mb-6 border border-red-200">
            <p className="text-red-700 mb-2 font-medium">Atenção: Esta ação não pode ser desfeita</p>
            <p className="text-red-600 text-sm">
              Quando você exclui sua conta, todas as suas informações pessoais, mensagens e 
              correspondências serão removidas permanentemente. Você não poderá recuperar esses dados.
            </p>
          </div>
          
          <p className="text-neutral-600 mb-6">
            Se você tem certeza que deseja excluir sua conta, clique no botão abaixo.
          </p>

          <Button 
            variant="destructive" 
            className="w-full" 
            onClick={() => setShowConfirmDialog(true)}
          >
            Excluir Minha Conta
          </Button>
        </Card>
      </div>

      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Você tem certeza absoluta?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação não pode ser desfeita. Isso excluirá permanentemente sua conta e 
              removerá todos os seus dados do nosso sistema.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="py-4">
            <p className="text-sm text-neutral-600 mb-2">
              Digite EXCLUIR para confirmar:
            </p>
            <Input
              placeholder="EXCLUIR"
              value={confirmText}
              onChange={(e) => setConfirmText(e.target.value)}
              className="mb-4"
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction 
              className="bg-red-600 hover:bg-red-700 text-white"
              onClick={handleDeleteAccount}
              disabled={confirmText !== "EXCLUIR" || deleteAccountMutation.isPending}
            >
              {deleteAccountMutation.isPending ? "Excluindo..." : "Sim, excluir minha conta"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}