import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { BottomNavigation } from "@/components/bottom-navigation";
import { MessageItem } from "@/components/message-item";
import { useAuth } from "@/hooks/use-auth";
import { Search } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Messages() {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  
  const { data: messages, isLoading } = useQuery({
    queryKey: ["/api/messages"],
    enabled: !!user,
  });
  
  if (!user) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p>Redirecionando para login...</p>
      </div>
    );
  }

  // Group messages by conversation
  const conversations = messages && messages.length > 0
    ? messages.reduce((acc, message) => {
        const otherUserId = message.senderId === user.id ? message.receiverId : message.senderId;
        
        if (!acc[otherUserId]) {
          acc[otherUserId] = {
            id: otherUserId,
            lastMessage: message,
            unreadCount: message.senderId !== user.id && !message.read ? 1 : 0
          };
        } else {
          const existingDate = new Date(acc[otherUserId].lastMessage.createdAt);
          const messageDate = new Date(message.createdAt);
          
          if (messageDate > existingDate) {
            acc[otherUserId].lastMessage = message;
          }
          
          if (message.senderId !== user.id && !message.read) {
            acc[otherUserId].unreadCount += 1;
          }
        }
        
        return acc;
      }, {} as Record<string, { id: number; lastMessage: any; unreadCount: number }>)
    : {};
  
  const conversationArray = Object.values(conversations || {})
    .sort((a, b) => new Date(b.lastMessage.createdAt).getTime() - new Date(a.lastMessage.createdAt).getTime());
  
  const filteredConversations = conversationArray.filter(conv => {
    // Would need to filter by name, but we don't have the other user's name in this demo
    return true;
  });

  return (
    <div className="min-h-screen bg-neutral-100 pb-20">
      <div className="bg-white shadow-sm">
        <div className="w-full max-w-md mx-auto px-6 py-4">
          <h1 className="text-lg font-medium">Mensagens</h1>
        </div>
      </div>
      
      <div className="w-full max-w-md mx-auto px-6 py-4">
        <Card className="rounded-lg shadow-sm">
          {/* Search Bar */}
          <div className="p-4 border-b border-neutral-200">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 h-4 w-4" />
              <Input
                type="text"
                placeholder="Pesquisar mensagens"
                className="w-full bg-neutral-100 border-0 rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-secondary/50"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          {/* Message List */}
          <div id="messagesList">
            {isLoading ? (
              // Loading skeletons
              <>
                {[1, 2, 3].map((i) => (
                  <div key={i} className="p-4 border-b border-neutral-200 flex items-center">
                    <Skeleton className="w-12 h-12 rounded-full mr-3" />
                    <div className="flex-1">
                      <div className="flex justify-between items-center mb-1">
                        <Skeleton className="h-5 w-24" />
                        <Skeleton className="h-4 w-10" />
                      </div>
                      <Skeleton className="h-4 w-full" />
                    </div>
                  </div>
                ))}
              </>
            ) : filteredConversations.length > 0 ? (
              filteredConversations.map((conversation) => (
                <MessageItem 
                  key={conversation.id}
                  conversationId={conversation.id}
                  lastMessage={conversation.lastMessage}
                  unreadCount={conversation.unreadCount}
                />
              ))
            ) : (
              // Empty state
              <div id="noMessages" className="p-8 text-center">
                <div className="w-16 h-16 bg-neutral-200 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-neutral-500"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                    />
                  </svg>
                </div>
                <h3 className="text-lg font-medium mb-2">Nenhuma mensagem</h3>
                <p className="text-neutral-600">Suas conversas aparecerão aqui.</p>
              </div>
            )}
          </div>
        </Card>
      </div>
      
      <BottomNavigation activeTab="messages" />
    </div>
  );
}
