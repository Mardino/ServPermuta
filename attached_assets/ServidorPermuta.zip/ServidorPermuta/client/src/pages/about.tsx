import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BottomNavigation } from "@/components/bottom-navigation";

export default function About() {
  const [_, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-neutral-100 pb-20">
      <div className="bg-white shadow-sm">
        <div className="w-full max-w-md mx-auto px-6 py-4">
          <div className="flex items-center">
            <Button
              variant="ghost"
              className="mr-2 p-0 h-9 w-9"
              onClick={() => navigate("/profile")}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-lg font-medium">Sobre o App</h1>
          </div>
        </div>
      </div>
      
      <div className="w-full max-w-md mx-auto px-6 py-4">
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-medium mb-4">Permuta Já</h2>
          <p className="text-neutral-600 mb-4">
            O Permuta Já é uma plataforma desenvolvida para facilitar as transferências por permuta entre funcionários públicos em Moçambique.
          </p>
          <p className="text-neutral-600 mb-4">
            Nosso objetivo é conectar profissionais que desejam mudar de localização, mantendo o mesmo cargo e nível salarial, tornando o processo de permuta mais ágil e eficiente.
          </p>
          <div className="bg-neutral-100 p-4 rounded-lg mb-4">
            <h3 className="font-medium mb-2">Recursos principais:</h3>
            <ul className="list-disc pl-5 space-y-1 text-neutral-600">
              <li>Cadastro detalhado de funcionários</li>
              <li>Sistema de busca avançado</li>
              <li>Matching automático entre profissionais compatíveis</li>
              <li>Chat interno para comunicação segura</li>
              <li>Notificações de novas correspondências</li>
            </ul>
          </div>
        </Card>
        
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-medium mb-4">Versão</h2>
          <p className="text-neutral-600">
            Versão 1.0.0 (Maio de 2023)
          </p>
        </Card>
        
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-medium mb-4">Equipe</h2>
          <p className="text-neutral-600 mb-4">
            O Permuta Já foi desenvolvido por uma equipe dedicada de profissionais moçambicanos que entendem as necessidades dos funcionários públicos no país.
          </p>
          <p className="text-neutral-600">
            Para contactar nossa equipe de suporte, envie uma mensagem para <span className="text-secondary">suporte@permutaja.co.mz</span>
          </p>
        </Card>
      </div>
      
      <BottomNavigation activeTab="account" />
    </div>
  );
}