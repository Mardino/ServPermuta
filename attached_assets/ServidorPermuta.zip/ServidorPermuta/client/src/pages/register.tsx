import { useState } from "react";
import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { RegisterSteps } from "@/components/register-steps";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { insertUserSchema } from "@shared/schema";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";

export default function Register() {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  const { login } = useAuth();
  const [step, setStep] = useState(1);
  
  const registerMutation = useMutation({
    mutationFn: async (data: z.infer<typeof insertUserSchema>) => {
      const response = await apiRequest("POST", "/api/auth/register", data);
      return response.json();
    },
    onSuccess: (data) => {
      login(data);
      toast({
        title: "Registro bem-sucedido",
        description: "Bem-vindo ao Permuta Já!",
      });
      navigate("/home");
    },
    onError: (error) => {
      toast({
        title: "Erro ao criar conta",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleRegister = (formData: z.infer<typeof insertUserSchema>) => {
    registerMutation.mutate(formData);
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="w-full max-w-md mx-auto px-6 py-6 flex flex-col">
        <div className="mb-6">
          <Button
            variant="ghost"
            className="flex items-center text-neutral-600 p-0 h-auto"
            onClick={() => navigate("/login")}
          >
            <ArrowLeft className="mr-1 h-4 w-4" />
            <span>Voltar</span>
          </Button>
        </div>
        
        <h2 className="text-2xl font-medium text-neutral-800 mb-6">Criar Conta</h2>
        
        <RegisterSteps 
          currentStep={step} 
          onNextStep={(nextStep) => setStep(nextStep)} 
          onPrevStep={(prevStep) => setStep(prevStep)}
          onRegister={handleRegister}
          isPending={registerMutation.isPending}
        />
      </div>
    </div>
  );
}
