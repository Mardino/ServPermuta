import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function Privacy() {
  const [_, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-neutral-100">
      <div className="bg-white shadow-sm">
        <div className="w-full max-w-md mx-auto px-6 py-4">
          <div className="flex items-center">
            <Button
              variant="ghost"
              className="mr-2 p-0 h-9 w-9"
              onClick={() => navigate("/")}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-lg font-medium">Política de Privacidade</h1>
          </div>
        </div>
      </div>
      
      <div className="w-full max-w-md mx-auto px-6 py-4">
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-medium mb-4">Política de Privacidade</h2>
          <p className="text-sm text-neutral-600 mb-4">
            Última atualização: Maio de 2023
          </p>
          
          <div className="prose prose-sm text-neutral-700">
            <p className="mb-4">
              Esta Política de Privacidade descreve como o Permuta Já coleta, usa e compartilha suas informações pessoais quando você utiliza nosso aplicativo.
            </p>
            
            <h3 className="text-lg font-medium mt-6 mb-2">1. Informações que Coletamos</h3>
            <p className="mb-2">Coletamos as seguintes informações pessoais:</p>
            <ul className="list-disc pl-5 mb-4">
              <li>Informações de perfil (nome, apelido, contato)</li>
              <li>Informações profissionais (setor, nível salarial, escalão)</li>
              <li>Localização atual e pretendida</li>
              <li>Mensagens enviadas dentro do aplicativo</li>
              <li>Dados de uso e interação com o aplicativo</li>
            </ul>
            
            <h3 className="text-lg font-medium mt-6 mb-2">2. Como Usamos suas Informações</h3>
            <p className="mb-2">Utilizamos suas informações para:</p>
            <ul className="list-disc pl-5 mb-4">
              <li>Criar e gerenciar sua conta no Permuta Já</li>
              <li>Encontrar correspondências adequadas para permuta</li>
              <li>Possibilitar a comunicação entre usuários</li>
              <li>Melhorar e personalizar a experiência do usuário</li>
              <li>Garantir a segurança e integridade do aplicativo</li>
            </ul>
            
            <h3 className="text-lg font-medium mt-6 mb-2">3. Compartilhamento de Informações</h3>
            <p className="mb-4">
              Compartilhamos suas informações de perfil com outros usuários dentro do aplicativo para facilitar o processo de permuta. Não vendemos ou compartilhamos suas informações com terceiros para fins de marketing.
            </p>
            
            <h3 className="text-lg font-medium mt-6 mb-2">4. Segurança dos Dados</h3>
            <p className="mb-4">
              Implementamos medidas de segurança para proteger suas informações pessoais. Utilizamos criptografia para proteger dados sensíveis, como senhas, e seguimos as melhores práticas da indústria para proteger contra acesso não autorizado.
            </p>
            
            <h3 className="text-lg font-medium mt-6 mb-2">5. Seus Direitos</h3>
            <p className="mb-2">Você tem os seguintes direitos em relação aos seus dados:</p>
            <ul className="list-disc pl-5 mb-4">
              <li>Acessar, corrigir ou excluir suas informações pessoais</li>
              <li>Revogar o consentimento para processamento de dados</li>
              <li>Solicitar a portabilidade de seus dados</li>
              <li>Opor-se ao processamento de seus dados em certas circunstâncias</li>
            </ul>
            
            <h3 className="text-lg font-medium mt-6 mb-2">6. Retenção de Dados</h3>
            <p className="mb-4">
              Mantemos suas informações pessoais enquanto você mantiver uma conta ativa no Permuta Já. Quando você excluir sua conta, seus dados pessoais serão removidos dos nossos sistemas em até 30 dias, exceto quando a retenção for necessária para cumprir obrigações legais.
            </p>
            
            <h3 className="text-lg font-medium mt-6 mb-2">7. Transferências Internacionais</h3>
            <p className="mb-4">
              O Permuta Já está localizado em Moçambique, e suas informações são processadas e armazenadas no país. Tomamos medidas para garantir que as transferências internacionais de dados, se necessárias, sejam realizadas de acordo com as leis aplicáveis de proteção de dados.
            </p>
            
            <h3 className="text-lg font-medium mt-6 mb-2">8. Alterações na Política de Privacidade</h3>
            <p className="mb-4">
              Podemos atualizar esta Política de Privacidade periodicamente. Notificaremos você sobre alterações significativas por meio de avisos no aplicativo ou por outros meios.
            </p>
            
            <h3 className="text-lg font-medium mt-6 mb-2">9. Contato</h3>
            <p className="mb-4">
              Se você tiver dúvidas sobre esta Política de Privacidade ou sobre o processamento de seus dados, entre em contato conosco pelo email: privacidade@permutaja.co.mz.
            </p>
          </div>
          
          <Button 
            className="w-full mt-6" 
            onClick={() => navigate("/")}
          >
            Voltar
          </Button>
        </Card>
      </div>
    </div>
  );
}