import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { forgotPasswordSchema } from "@shared/schema";

export default function ForgotPassword() {
  const [_, navigate] = useLocation();
  const { toast } = useToast();
  
  const form = useForm<z.infer<typeof forgotPasswordSchema>>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: {
      contact: "",
    },
  });

  const forgotPasswordMutation = useMutation({
    mutationFn: async (data: z.infer<typeof forgotPasswordSchema>) => {
      const response = await apiRequest("POST", "/api/auth/forgot-password", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Código enviado",
        description: data.message,
      });
      navigate("/login");
    },
    onError: (error) => {
      toast({
        title: "Erro ao recuperar senha",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function onSubmit(data: z.infer<typeof forgotPasswordSchema>) {
    forgotPasswordMutation.mutate(data);
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="w-full max-w-md mx-auto px-6 py-10 flex flex-col min-h-screen">
        <div className="mb-8">
          <Button
            variant="ghost"
            className="flex items-center text-neutral-600 p-0 h-auto"
            onClick={() => navigate("/login")}
          >
            <ArrowLeft className="mr-1 h-4 w-4" />
            <span>Voltar</span>
          </Button>
        </div>
        
        <h2 className="text-2xl font-medium text-neutral-800 mb-4">Recuperar senha</h2>
        <p className="text-neutral-600 mb-8">
          Digite seu número de WhatsApp para receber um código de recuperação.
        </p>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <FormField
              control={form.control}
              name="contact"
              render={({ field }) => (
                <FormItem className="mb-8">
                  <FormLabel>Contacto (WhatsApp)</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="+258 xx xxx xxxx"
                      {...field}
                      className="input-field"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              className="primary-button"
              disabled={forgotPasswordMutation.isPending}
            >
              {forgotPasswordMutation.isPending ? "Enviando..." : "Enviar código"}
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
